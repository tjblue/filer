A sample archive to browse and extract.
